-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 23, 2018 at 03:49 PM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hm`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `Bid` int(11) NOT NULL,
  `Fullname` varchar(200) NOT NULL,
  `Username` varchar(200) NOT NULL,
  `Roomtype` varchar(200) NOT NULL,
  `Email` varchar(200) NOT NULL,
  `Institute` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`Bid`, `Fullname`, `Username`, `Roomtype`, `Email`, `Institute`) VALUES
(1, 'Sadman Ahsan', 'sadman', 'null', 'ahsan.susmoy@gmail.com', 'AUST'),
(2, 'Muhammad Alvi', 'alvi', 'Single', 'ahsan.susmoy@gmail.com', 'AUST'),
(3, 'Md Susmoy', 'sadmansusmoy', 'Double', 'ahsan.susmoy@gmail.com', 'AUST'),
(4, '', '', 'Single', '', ''),
(5, '', '', 'Single', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `cid` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `query` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`cid`, `username`, `email`, `query`) VALUES
(1, 'sadman', 'ahsan.susmoy@gmail.com', 'Vua'),
(2, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `sid` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `mobile` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`sid`, `username`, `password`, `mobile`, `email`, `address`) VALUES
(1, 'g', 'g', 'null', 'ahsan.susmoy@gmail.com', 'Nakhalpara'),
(2, 'h', 'm', 'null', 'ahsan.susmoy@gmail.com', 'Dhaka'),
(3, 'sadman', 'sadman', '01756938390', 'ahsan.susmoy@gmail.com', 'Dhaka'),
(4, 'g', 'g', '01715255357', 'ahsan.susmoy@gmail.com', 'Kishorganj'),
(5, 'alvi', '1234', '01715255357', 'ahsan.susmoy@gmail.com', 'sdd'),
(6, 'sadmansusmoy', '123456', '01715255357', 'ahsan.susmoy@gmail.com', '235/2 East Nakhalpara'),
(7, 'Adnan', '123456adnan', '01715255357', 'ahsan.susmoy@gmail.com', '235/2East Nakhalpara'),
(8, '', '', '', '', ''),
(9, 'sadman', '123456789', '', '', ''),
(10, 'Md Sadman Ahsan', '123456789', '01756938390', 'ahsan.susmoy@gmail.com', 'Dhaka');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`Bid`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`sid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `Bid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
